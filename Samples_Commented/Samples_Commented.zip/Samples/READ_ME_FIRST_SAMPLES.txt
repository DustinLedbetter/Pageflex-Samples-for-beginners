/***********************************************************************************************************************************
*                                                 GOD First                                                                        *
* Author: Dustin Ledbetter                                                                                                         *
* Release Date: 9-25-2018                                                                                                          *
* Folder: Samples                                                                                                                  *
* Purpose: This file is to help understand what is in this folder                                                                  *
************************************************************************************************************************************/

This folder contains the sample extensions that the book says come with the storefront deployments.

I have added comments and helpful tips to these as the originals lack proper guidance.